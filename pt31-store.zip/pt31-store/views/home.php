<?php
echo "<p>Welcome to Store manager</p>";
//TODO add some content, such as text and images that fit a main page for a store web page.
