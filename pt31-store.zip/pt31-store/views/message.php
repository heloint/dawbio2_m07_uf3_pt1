<div class='alert alert-warning'>
<strong><?php echo $params['message']; ?></strong>
</div>