<?php
echo "<h2>Login page</h2>";
echo "<p>Sorry! Page under construction</p>";