<h2>Warehouse management page</h2>
<p>Sorry! Page under construction</p>